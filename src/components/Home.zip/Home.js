import React from 'react';


function Home(){
    return (
        <div>
            <ul>
                <li>match 1</li>
                <li>match 2</li>
                <li>match 3</li>
            </ul>
        </div>
    )
}

export default Home;